# Mohammed Saihaan Moosa — Professional Digital Portfolio

A responsive, five-page portfolio website built with HTML and CSS, with a small JavaScript enhancement for mobile navigation.

## Files
- `index.html` — Home
- `about.html` — About Me
- `projects.html` — Projects
- `reflection.html` — Professional Reflection
- `contact.html` — Contact
- `styles.css` — Shared responsive styling
- `script.js` — Mobile navigation and current year

## Add your professional photo
1. Create an `assets` folder if it does not exist.
2. Add your photo as `assets/profile.jpg`.
3. In `index.html`, replace the `profile-placeholder` `<div>` with:
   `<img class="profile-photo" src="assets/profile.jpg" alt="Professional photograph of Mohammed Saihaan Moosa">`
4. Add this CSS to `styles.css`:
   `.profile-photo { display:block; width:100%; aspect-ratio:4/5; object-fit:cover; border-radius:17px; }`

## Publish with GitHub Pages
1. Sign in to https://github.com/SMoosa-Dev.
2. Create a **public** repository named `portfolio` (or another name you prefer).
3. Upload all files and the `assets` folder, keeping the five HTML files and shared assets at the repository root.
4. Open the repository's **Settings**.
5. In the sidebar, select **Pages**.
6. Under **Build and deployment**, choose **Deploy from a branch**.
7. Select the `main` branch and the `/(root)` folder, then click **Save**.
8. Wait for the deployment to finish. In Settings → Pages, use **Visit site** to open the published website.
9. For a project repository named `portfolio`, the URL is normally `https://SMoosa-Dev.github.io/portfolio/` (GitHub usernames are case-insensitive in URLs). Use the exact URL shown by GitHub Pages.
10. Test all five pages, the email link, GitHub and LinkedIn links, and the mobile menu before submitting.

GitHub Pages can take several minutes to publish changes. Do not submit until the site is publicly accessible.
